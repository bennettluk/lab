#include <stdio.h>
#include <stdlib.h>
#include "Han_Xin.h"
int main(void)
{
	Han_Xin_1();
	Han_Xin_2();
	Han_Xin_3();
	Han_Xin_4();
	Han_Xin_5();

	 printf("\n");
	 system("pause");
}