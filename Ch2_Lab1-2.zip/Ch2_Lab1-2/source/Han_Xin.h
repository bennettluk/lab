int Han_Xin_1();
int Han_Xin_2();
int Han_Xin_3();
int Han_Xin_4();
int Han_Xin_5();